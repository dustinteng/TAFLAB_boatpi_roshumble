// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TAFLAB_MSGS__MSG__CONTROL_DATA_HPP_
#define TAFLAB_MSGS__MSG__CONTROL_DATA_HPP_

#include "taflab_msgs/msg/detail/control_data__struct.hpp"
#include "taflab_msgs/msg/detail/control_data__builder.hpp"
#include "taflab_msgs/msg/detail/control_data__traits.hpp"
#include "taflab_msgs/msg/detail/control_data__type_support.hpp"

#endif  // TAFLAB_MSGS__MSG__CONTROL_DATA_HPP_
