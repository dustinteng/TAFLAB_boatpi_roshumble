// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from taflab_msgs:msg/CalibrationData.idl
// generated code does not contain a copyright notice

#ifndef TAFLAB_MSGS__MSG__DETAIL__CALIBRATION_DATA__TYPE_SUPPORT_H_
#define TAFLAB_MSGS__MSG__DETAIL__CALIBRATION_DATA__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "taflab_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_taflab_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  taflab_msgs,
  msg,
  CalibrationData
)();

#ifdef __cplusplus
}
#endif

#endif  // TAFLAB_MSGS__MSG__DETAIL__CALIBRATION_DATA__TYPE_SUPPORT_H_
