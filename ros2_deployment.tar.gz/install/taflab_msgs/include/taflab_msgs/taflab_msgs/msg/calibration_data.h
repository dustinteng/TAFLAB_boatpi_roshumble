// generated from rosidl_generator_c/resource/idl.h.em
// with input from taflab_msgs:msg/CalibrationData.idl
// generated code does not contain a copyright notice

#ifndef TAFLAB_MSGS__MSG__CALIBRATION_DATA_H_
#define TAFLAB_MSGS__MSG__CALIBRATION_DATA_H_

#include "taflab_msgs/msg/detail/calibration_data__struct.h"
#include "taflab_msgs/msg/detail/calibration_data__functions.h"
#include "taflab_msgs/msg/detail/calibration_data__type_support.h"

#endif  // TAFLAB_MSGS__MSG__CALIBRATION_DATA_H_
